Description
===========

Test package for an exercise.